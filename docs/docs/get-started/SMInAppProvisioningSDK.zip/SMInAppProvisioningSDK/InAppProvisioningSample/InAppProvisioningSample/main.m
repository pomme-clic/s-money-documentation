//
//  main.m
//  InAppProvisioningSample
//
//  Created by Gerald Mephane on 27/09/2019.
//  Copyright © 2019 S-money. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
