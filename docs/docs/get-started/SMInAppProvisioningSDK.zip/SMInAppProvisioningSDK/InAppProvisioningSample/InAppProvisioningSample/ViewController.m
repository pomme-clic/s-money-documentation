//
//  ViewController.m
//  InAppProvisioningSample
//
//  Created by Gerald Mephane on 27/09/2019.
//  Copyright © 2019 S-money. All rights reserved.
//

#import "ViewController.h"
#import <SmoneyInAppProvisioning.h>
#import <SMIAPButtonManager.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [SmoneyInAppProvisioning setUserID:@"UserId"];
    
    PKAddPassButton *button = [[PKAddPassButton alloc] init];
    
    // manage button visibility
    button.hidden = [PKAddPassesViewController canAddPasses] ? NO : YES;
    
    [button addTarget:self action:@selector(onAddPass) forControlEvents:UIControlEventTouchUpInside];

    button.center = CGPointMake(self.view.frame.size.width  / 2,
                          self.view.frame.size.height / 2);
    
    [self.view addSubview:button];
}

-(void) onAddPass {
    // Initialize manager with pass configuration
    SMIAPButtonManager* manager = [[SMIAPButtonManager  alloc] initWithCardHolderName:@"UserHolderName" primaryAccountIdentifier:@"CardPrimaryAccountIdentifier" primaryAccountSuffix:@"CardPrimaryAccountSuffix" delegate:self sender:self];
    
    // Start add payment pass
    [manager addPass];
}


- (void)didFinishWithSuccess {
    
}

- (void)didFinishWithError:(NSError *) error {
    
}

@end
