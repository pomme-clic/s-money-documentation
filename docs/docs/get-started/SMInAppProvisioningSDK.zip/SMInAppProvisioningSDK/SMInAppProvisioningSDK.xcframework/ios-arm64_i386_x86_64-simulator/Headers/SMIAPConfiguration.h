//
//  SMIAPConfiguration.h
//  SMInAppProvisioningSDK
//
//  Created by Gerald Mephane on 20/09/2019.
//  Copyright © 2019 S-money. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SMIAPConfiguration : NSObject

@property (nonatomic, assign) BOOL enableJailbreakDetection;
@property (nonatomic, assign) BOOL enableEmulatorDetection;
@property (nonatomic, assign) BOOL enableDebugDetection;

+ (SMIAPConfiguration*)defaultConfiguration;

@end

NS_ASSUME_NONNULL_END
