//
//  SMIAPButtonManaer.h
//  SMInAppProvisioningSDK
//
//  Created by Gerald Mephane on 20/09/2019.
//  Copyright © 2019 S-money. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@import PassKit;

NS_ASSUME_NONNULL_BEGIN

typedef enum {
    SMIAPAddPaymentPassErrorUnsupported          = 1,
    SMIAPAddPaymentPassErrorUserCancelled        = 2,
    SMIAPAddPaymentPassErrorSystemCancelled      = 3,
    SMIAPErrorCodeUserCannotBeFound              = 4,
    SMIAPErrorCodeInvalidParameter               = 5,
    SMIAPErrorCodeCardNotFound                   = 6,
    SMIAPErrorCodeOperationNotAuthorized         = 7,
    SMIAPErrorCodeOperationInvalid               = 8,
    SMIAPErrorCodeOAuthTokenExpired              = 9,
    SMIAPErrorCodeOAuthTokenInvalid              = 10,
    SMIAPErrorSecurityCheck                      = 11
} SMIAPErrorCode;

@class SMIAPButtonManager;
@protocol SMIAPButtonManagerDelegate <NSObject>

/* Error parameter will use codes from the SMIAPErrorCode enumeration, using the SMIAPErrorDomain domain.
 */
- (void)didFinishWithError:(NSError *) error;

- (void)didFinishWithSuccess;

@end



@interface SMIAPButtonManager : NSObject <PKAddPaymentPassViewControllerDelegate>

@property (nonatomic, strong) UIViewController *sender;

@property (weak, nonatomic) id<SMIAPButtonManagerDelegate> delegate;


/** Call this class method to initialize SMIAPButtonManager
 @param cardHolderName The name of the person as shown on the card.
 @param primaryAccountIdentifier A primary account identifier, used to filter out pass libraries.
 @param primaryAccountSuffix The last four or five digits of the card’s number.
 @param delegate The protocol used to get add pass events.
 @param sender The view controller used to present PKAddPaymentPassViewController.
 */
- (instancetype)initWithCardHolderName:(NSString *)cardHolderName primaryAccountIdentifier:(NSString *)primaryAccountIdentifier primaryAccountSuffix:(NSString *)primaryAccountSuffix delegate:(id<SMIAPButtonManagerDelegate>)delegate sender:(UIViewController *) sender;

/** Call this class method to add your payment pass
 */
- (void) addPass;
#ifdef DEBUG
- (void)testEnrollCard:(NSString *)cardId
                rsaKey:(NSArray<NSString *> *)rsaKey
                 nonce:(NSString *)nonce
        nonceSignature:(NSString *)nonceSignature;
- (void)testGetCall;
#endif

@end

NS_ASSUME_NONNULL_END
