//
//  SmoneyInAppProvisioning.h
//  SMInAppProvisioningSDK
//
//  Created by Gerald Mephane on 17/09/2019.
//  Copyright © 2019 S-money. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SMIAPConfiguration.h"

NS_ASSUME_NONNULL_BEGIN

@interface SmoneyInAppProvisioning : NSObject

/** Active the log in console to see what appends with the SmoneyInAppProvisioning SDK.
 @param value YES or NO
 */
+ (void)setDebugMode:(BOOL)value;

/** Call this class method to initialize the SmoneyInAppProvisioning SDK.
 @param accessToken That we have provided.
 */
+ (void)initWithPartnerAccessToken:(NSString *)accessToken;

/** Call this class method to initialize the SmoneyInAppProvisioning SDK.
 @param accessToken That we have provided.
 @param config That we have provided.
 */
+ (void)initWithPartnerAccessToken:(NSString *)accessToken config:(SMIAPConfiguration *)config;

/** Call this class method to report your own user ID to our server.
 @param userID Whatever you want, that can be the ID of the user in your database. It's recommended to have a different userID for each user of your app.
 */
+ (void) setUserID:(NSString *)userID;

/** Call this class method to return the reported own userID
 @return The reported own userID as a NSString
 */
+ (NSString *) userID;

@end

NS_ASSUME_NONNULL_END
