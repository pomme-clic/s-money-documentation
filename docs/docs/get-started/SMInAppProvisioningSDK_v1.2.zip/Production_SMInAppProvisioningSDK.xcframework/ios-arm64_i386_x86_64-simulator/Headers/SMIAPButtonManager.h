//
//  SMIAPButtonManaer.h
//  SMInAppProvisioningSDK
//
//  Created by Gerald Mephane on 20/09/2019.
//  Copyright © 2019 S-money. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@import PassKit;

NS_ASSUME_NONNULL_BEGIN

typedef enum {
    SMIAPAddPaymentPassErrorUnsupported             = 1,
    SMIAPAddPaymentPassErrorUserCancelled           = 2,
    SMIAPAddPaymentPassErrorSystemCancelled         = 3,
    SMIAPErrorCodeUnknwonError                      = 4,
    SMIAPErrorCodeInvalidParameter                  = 5,
    SMIAPErrorCodeCardNotFound                      = 6,
    SMIAPErrorCodeCardEnrollmentDenied              = 7,
    SMIAPErrorCodeInvalidToken                      = 8,
    SMIAPErrorSecurityCheck                         = 9,
    SMIAPErrorMissingResponseProperty               = 10,
    SMIAPErrorCouldNotCreateNSData                  = 11,
    SMIAPErrorCouldNotDecodeValue                   = 12
} SMIAPErrorCode;

@class SMIAPButtonManager;
@protocol SMIAPButtonManagerDelegate <NSObject>

/* Error parameter will use codes from the SMIAPErrorCode enumeration, using the SMIAPErrorDomain domain.
 */
- (void)didFinishWithError:(NSError *) error;
- (void)didFinishWithSuccess:(PKPaymentPass *)pass;

@end

@interface SMIAPButtonManager : UIViewController

@property (nonatomic, strong) UIViewController *sender;
@property (nonatomic, strong) NSString *cardID;
@property (weak, nonatomic) id<SMIAPButtonManagerDelegate> delegate;

/** Call this class method to initialize SMIAPButtonManager
 @param cardHolderName The name of the person as shown on the card.
 @param primaryAccountSuffix The last four or five digits of the card’s number.
 @param primaryAccountIdentifier A primary account identifier, used to filter out pass libraries.
 @param cardID The card identifier to perform the enrollment.
 @param delegate The protocol used to get add pass events.
 @param sender The view controller used to present PKAddPaymentPassViewController.
 */
- (instancetype)initWithCardHolderName:(NSString * _Nonnull)cardHolderName
                  primaryAccountSuffix:(NSString * _Nonnull)primaryAccountSuffix
              primaryAccountIdentifier:(NSString *_Nullable)primaryAccountIdentifier
                                cardID:(NSString * _Nonnull)cardID
                              delegate:(id<SMIAPButtonManagerDelegate> _Nonnull)delegate
                                sender:(UIViewController * _Nonnull) sender;

/** Call this class method to add your payment pass
 */
- (void)addPass;

@end

NS_ASSUME_NONNULL_END
