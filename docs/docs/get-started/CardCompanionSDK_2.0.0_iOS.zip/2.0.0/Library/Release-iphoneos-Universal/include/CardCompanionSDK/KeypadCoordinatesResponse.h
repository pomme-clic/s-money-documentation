#import <Foundation/Foundation.h>
#import "ExecutionResponse.h"

@interface KeypadCoordinatesResponse : ExecutionResponse

@property(nonatomic, copy) NSString * keypadCoordinates;

-(id) initWithResponseDict:(NSDictionary *)dict;

@end
