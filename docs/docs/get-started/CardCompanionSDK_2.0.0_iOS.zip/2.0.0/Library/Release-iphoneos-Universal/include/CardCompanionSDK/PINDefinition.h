#import <Foundation/Foundation.h>
#import "ExecutionResponse.h"
#import "KeypadCoordinatesResponse.h"
#import "PinResponse.h"

@interface PINDefinition : NSObject

#pragma mark - Pin Definition

+ (ExecutionResponse *) definePINHMAC: (NSString *)hostURL
                               bankId: (NSString *)bankId
                             uniqueId: (NSString *)uniqueId
                            timestamp: (NSNumber *)ts
                              hashMac: (NSString *)hashMac
                                  pin: (NSString *)pin;

+ (ExecutionResponse *) definePINToken: (NSString *)hostURL
                                 token: (NSString *)token
                                   pin: (NSString *)pin
                             signature: (NSString *)signature;

+ (KeypadCoordinatesResponse *) getKeypadCoordinates: (NSString *)hostURL
                                              bankId: (NSString *)bankId
                                            uniqueId: (NSString *)uniqueId
                                          keypadSize: (int)keypadSize;

+ (ExecutionResponse *) definePINTokenCB: (NSString *)hostURL
                                   token: (NSString *)token
                              pinIndexes: (NSString *)pinIndexes
                               signature: (NSString *)signature;

@end
