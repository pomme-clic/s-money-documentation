#import <Foundation/Foundation.h>
#import "ExecutionResponse.h"
#import "PINResponse.h"

@interface PINDistribution : NSObject <AVAudioPlayerDelegate> {
}

/*
 * Get singleton for PIN Distribution
 */
+(PINDistribution *)sharedInstance;

#pragma mark - Pin Distribution

/*
 *
 * Pin Distribution: GET Pin Request
 */
+ (PINResponse *) retrievePINCaptcha: (NSString*)hostURL
                              bankId: (NSString*)bankId
                            uniqueId: (NSString*)uniqueId
                  authenticationCode: (NSString*)authenticationCode
                           timestamp: (NSNumber*)timestamp
                             hashMac: (NSString*)hashMac;

/*
 *
 * Pin Distribution: Notify Request
 */
+ (ExecutionResponse *) notifyDelivery: (NSString *)hostURL
                                bankId: (NSString *)bankId
                              uniqueId: (NSString *)uniqueId
                             sessionId: (NSString *)sessionId
                                status: (NSString *)status;

/*
 *
 * Pin Distribution: GET Pin Captcha Token Request
 */
+ (PINResponse *) retrievePINCaptcha: (NSString *)hostURL
                               token: (NSString *)token
                           signature: (NSString *)signature;

/*
 *
 * Pin Distribution: Notify Token Request
 */
+ (ExecutionResponse *) notifyDelivery: (NSString *)hostURL
                                 token: (NSString *)token
                             sessionId: (NSString *)sessionId
                                status: (NSString *)status;

/*
 * Pin Distribution: Play PIN Audio request
 */
-(PINResponse *)playPINAudio: (NSString *)hostURL
                       token: (NSString *)token
                   signature: (NSString *)signature
                audioProfile: (NSString *)audioProfile
               audioTemplate: (NSString *)audioTemplate
                 audioVolume: (float)audioVolume;

/*
 * Pin Distribution: Play PIN Audio request
 */
-(PINResponse *)playPINAudio: (NSString *)hostURL
                       token: (NSString *)token
                   signature: (NSString *)signature
                audioProfile: (NSString *)audioProfile
               audioTemplate: (NSString *)audioTemplate;

@end
