#import <Foundation/Foundation.h>
#import "ExecutionResponse.h"

@interface PINResponse :ExecutionResponse

@property (nonatomic,copy) NSString *sessionId;
@property (nonatomic,copy) NSData *imageData;
@property (nonatomic,copy) NSString *freeField;

-(id) initWithResponseDict:(NSDictionary *)dict;
-(id) initWithCaptchaTokenResponseDict:(NSDictionary *)dict privateKey:(SecKeyRef)privateKey;
-(id) initWithAudioTokenResponseDict:(NSDictionary *)dict privateKey:(SecKeyRef)privateKey;

@end
