/*
Architectures for iPhone/iPad devices (i.e. Release-iphoneos-Universal):
    armv7
    armv7s: supported since A6 processor (i.e. iphone5)
    arm64: supported since A7 processor (i.e. iphone5S)
Architectures for macOS computers (i.e. Release-iphonesimulator-Universal):
    i386: macOS 32 bits
    x86_64: macOS 64 bits
*/
#import <Foundation/Foundation.h>

@interface CardCompanionSDK : NSObject

extern NSString * const SDK_VERSION;

+ (NSString *) getSDKVersion;

@end
