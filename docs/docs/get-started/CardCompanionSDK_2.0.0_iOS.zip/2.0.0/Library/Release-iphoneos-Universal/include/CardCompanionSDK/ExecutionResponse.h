#import <Foundation/Foundation.h>

@interface ExecutionResponse : NSObject

@property NSInteger errorCode;
@property (retain) NSString *errorMessage;

-(id) initDictionary:(NSDictionary *)dict;

-(id) initError: (NSInteger)codeError description:(NSString *)description;


@end

